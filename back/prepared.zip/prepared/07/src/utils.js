export function square (x) {
  return x * x
}

export function cube (x) {
  return x * x * x
}

export function floor (x) {
  return Math.floor(x)
}

export function ceil (x) {
  return Math.ceil(x)
}
