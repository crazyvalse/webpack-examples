import { ceil } from './utils'

function foo () {
  document.getElementById('app').innerHTML = ceil(3.123321)
}

foo()
