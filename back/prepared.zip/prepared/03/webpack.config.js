module.exports = {
  entry: {
    app: './src/index.js'
  },
  output: {
    filename: 'bundle.js',
    path: '/Users/CodingNutsZac/Documents/github/webpack-examples-new/prepared/03/dist'
  }
}
